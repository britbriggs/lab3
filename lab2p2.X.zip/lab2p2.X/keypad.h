/* 
 * File:   keypad.h
 * Author: Brit Briggs
 *
 * Created on February 25, 2016, 12:39 PM
 */

#ifndef KEYPAD_H
#define	KEYPAD_H

#ifdef	__cplusplus
extern "C" {
#endif

    void initKeypad();
    char scanKeypad();
    void keyCode(char lcdNum);
    


#ifdef	__cplusplus
}
#endif

#endif	/* KEYPAD_H */

