/* 
 * File:   switch.h
 * Author: Garrett
 *
 * Created on September 19, 2015, 10:46 AM
 */

#ifndef SWITCH_H
#define	SWITCH_H

#define TRIS_SW2 TRISAbits.TRISA7 // pin 6
#define CNIE_SW2 CNENAbits.CNIEA7 //
#define CNPU_SW2 CNPUAbits.CNPUA7
#define SW2 PORTAbits.RA7

#define TRIS_SW1 TRISDbits.TRISD6 // pin 6
#define CNIE_SW1 CNENDbits.CNIED6 //
#define CNPU_SW1 CNPUDbits.CNPUD6
#define SW1 PORTDbits.RD6

void initSW1();
void initSW2();


#endif	/* SWITCH_H */

