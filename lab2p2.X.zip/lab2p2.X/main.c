// ******************************************************************************************* //
//
// File:         lab1p2.c
// Date:         12-30-2014
// Authors:      Garrett Vanhoy
//
// Description: 
// ******************************************************************************************* //

#include <xc.h>
#include <sys/attribs.h>
#include "lcd.h"
#include "timer.h"
#include "switch.h"
#include "config.h"
#include "interrupt.h"


// ******************************************************************************************* //
#define DEBOUNCE_DELAY_MS 1

typedef enum stateTypeEnum{
    debouncePress, debounceRelease, waitForPress, waitForRelease
} stateType;

volatile stateType state = waitForPress;
volatile char lcdNum;


int main(void)
{
    SYSTEMConfigPerformance(10000000);
    enableInterrupts();
    
    
    
    initKeypad();               // Initialize KeyPad
    initLCD();                  // Initialize LCD

    clearLCD();                 //Clear LCD 
    printStringLCD("Enter");    // Start LCD with Enter
    moveCursorLCD(0,1);     //Move Cursor to second row
    
    int i;
    
    while(1)
    {
        switch(state){
            case debouncePress:
                
                delayUs(5000);       
                lcdNum=scanKeypad();
                printCharLCD(lcdNum);
                
                if(lcdNum==-1) state=waitForPress;                 // Keeps the states in proper order in case double press is detected
                else state=waitForRelease;

                keyCode(lcdNum);                // Code logic for the Keypad
                
                break;
            case waitForRelease:
             
                break;
            case waitForPress:
                break;
            case debounceRelease:
                delayUs(5000);
                state=waitForPress;
                break;
                
        }
        
    }
    
    return 0;
}


void __ISR(_CHANGE_NOTICE_VECTOR, IPL7SRS) _CNInterrupt( void ){
    
    PORTF;
    PORTG;
    PORTD;
    
    IFS1bits.CNFIF = 0;         // Put down the flag
    IFS1bits.CNGIF = 0;         // Put down the flag
    IFS1bits.CNDIF = 0;         // Put down the flag
    
    if (state == waitForPress)state = debouncePress;      //Same state machine as p1         
    else if(state == waitForRelease)state = debounceRelease; 

}


