/*
 * File:   timer.c
 * Authors:
 *
 * Created on December 30, 2014, 8:07 PM
 */

#include <xc.h>
#include "timer.h"
#include <stdio.h>

#define preScalar256 3

#define Enable 1
#define defaultPriority 7
#define Down 0
#define Disable 0

void initTimer1(){

    
    TMR1=0;
    T1CONbits.TCKPS=preScalar256;       //Prescalar 256
    T1CONbits.TCS=0;        
    PR1=390;            //PR for 10ms timer
    T1CONbits.ON=0;     //Initial timer state is off
    IFS0bits.T1IF=Down;     //Flag down
    IEC0bits.T1IE=Enable;       //Enable interrupt
    IPC1bits.T1IP=defaultPriority;  //Priority 7
    
}


void startTimer1(){
    PR1=391;        
    T1CONbits.ON=1;         //Start timer 
    IEC0bits.T1IE=Enable;       
    IFS0bits.T1IF = Down;
}
void stopTimer1(){
    T1CONbits.ON=0;
    IEC0bits.T1IE=Disable;
    IFS0bits.T1IF=0;
}


void delayUs(unsigned int delay){

    T2CONbits.TCKPS = 0; //prescalar of 1
    T2CONbits.TCS = 0;
    IFS0bits.T2IF = 0;
    TMR2 = 0;
    PR2 = delay*9;
    IFS0bits.T2IF = 0;
    T2CONbits.ON = 1;
    while(IFS0bits.T2IF == 0);
    T2CONbits.ON = 0;
}

char* getTimeString(const long int counter, char* time){
    int milliseconds;
    int seconds;
    int minutes;
    
    
    milliseconds=counter%100;           //%100 gives ms
    
    seconds=(counter/100)%60;           //%600 gives seconds
    minutes=(counter/100)/60;           // /600 gives minutes

    sprintf(time, "%02d:%02d:%02d", minutes, seconds, milliseconds);    //Format String
  
    return time;
    
}