// ******************************************************************************************* //
//
// File:         lab1p2.c
// Date:         12-30-2014
// Authors:      Garrett Vanhoy
//
// Description: 
// ******************************************************************************************* //

#include <xc.h>
#include <sys/attribs.h>
#include "lcd.h"
#include "timer.h"
#include "leds.h"
#include "switch.h"
#include "config.h"
#include "interrupt.h"


// ******************************************************************************************* //
#define DEBOUNCE_DELAY_MS 1

typedef enum stateTypeEnum{
    debouncePress, debounceRelease, waitForPress, waitForRelease
} stateType;

volatile stateType state = waitForPress;
volatile int switchPressedFlag = 0;
volatile long int counter=0;
volatile int resetFlag=0;
volatile char lcdNum;
volatile int count=0;
volatile int secondRowFlag=0;
int main(void)
{
    SYSTEMConfigPerformance(10000000);
    initKeypad();
    initLCD();                  // Initialize LCD
    enableInterrupts();
    clearLCD();
    int i;
    
    while(1)
    {
        switch(state){
            case debouncePress:
                
                  delayUs(50);

                
                  lcdNum=scanKeypad();
                
                count=count+1;
                if(count==17 && secondRowFlag==1){
                    clearLCD();
                    secondRowFlag=0;
                    count=1;
                    
                    printCharLCD(lcdNum); 
                }
                else if(count==16 && secondRowFlag==0){
                    printCharLCD(lcdNum); 
                    moveCursorLCD(0,1);
                    secondRowFlag=1;
                    count=0;
                }
                else{
                    printCharLCD(lcdNum); 
                }
                
                if(lcdNum==-1){
                    state=waitForPress;
                }
                else{               
                    state=waitForRelease;
                }
                
                
                break;
            case waitForRelease:
                break;
            case waitForPress:
                break;
            case debounceRelease:
                delayUs(50);
                state=waitForPress;
                break;
        }
        
    }
    
    return 0;
}


void __ISR(_CHANGE_NOTICE_VECTOR, IPL7SRS) _CNInterrupt( void ){
    
    PORTF;
    PORTG;
    PORTD;
    
    IFS1bits.CNFIF = 0;         // Put down the flag
    IFS1bits.CNGIF = 0;         // Put down the flag
    IFS1bits.CNDIF = 0;         // Put down the flag
    
    if (state == waitForPress) state = debouncePress;            //Same state machine as p1
    else if(state == waitForRelease) state = debounceRelease; 
    
   // else{
      
  //  }

}


