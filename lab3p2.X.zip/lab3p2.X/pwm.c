#include <xc.h>
#include "pwm.h"

void initPWM1(){
    leftWheelBackward = 0b0000; // map OC1 to RD1 l b
    leftWheelForward = 0b0000; // map OC1 to RD0 l f

    OC1CON = 0x0000; // Turn off OC1 while doing setup.
    OC1R = 0; // Initialize primary Compare Register
    OC1RS =0; // Initialize secondary Compare Register
    OC1CON = 0x0006; // Configure for PWM mode
    OC1CONSET = 0x8000; // Enable OC1
}

void initPWM2(){
    rightWheelBackward = 0b0000; // map OC2 to RD5 r b
    rightWheelForward = 0b0000; // map OC2 to RD8 r f

    OC2CON = 0x0000; // Turn off OC2 while doing setup.
    OC2R =0; // Initialize primary Compare Register
    OC2RS =0; // Initialize secondary Compare Register
    OC2CON = 0x0006; // Configure for PWM mode
    OC2CONSET = 0x8000; // Enable OC2
}


void initHbridge(){
    HbridgeEN1=Output;
    HbridgeEN2=Output;
    
    LATGbits.LATG0=1;
    LATGbits.LATG13=1;
    
    
    
}