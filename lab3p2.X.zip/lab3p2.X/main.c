


#include <xc.h>
#include <sys/attribs.h>
#include "adc.h"
#include "config.h"
#include "interrupt.h"
#include "lcd.h"
#include "pwm.h"
#include "switch.h"




typedef enum stateTypeEnum{
    forward, idleForward, idleBackward, backward
} stateType;
volatile stateType state = forward;
volatile float pinVoltage=0;
volatile float value=0;
volatile int potFlag;
volatile int switchPressedFlag=0;


int main(void){
    char analogVoltage[]="0.00";

    SYSTEMConfigPerformance(10000000);
    initLCD();                  // Initialize LCD

    initHbridge();
    initPWM1();
    initPWM2();
    initADC();
    
    initTimer2();
    initSwitch1();

    enableInterrupts();
    moveCursorLCD(0,0);
    
    while(1){
        switch(state){
            case forward:
                leftWheelBackward = 0b0000; // map OC2 to RD1 l b
                leftWheelForward = 0b1100; // map OC2 to RD0 l f
                rightWheelBackward = 0b0000; // map OC2 to RD5 r b
                rightWheelForward = 0b1011; // map OC2 to RD8 r f
                break;
            case backward:
                leftWheelBackward = 0b1100; // map OC2 to RD1 l b
                leftWheelForward = 0b0000; // map OC2 to RD0 l f
                rightWheelBackward = 0b1011; // map OC2 to RD5 r b
                rightWheelForward = 0b0000; // map OC2 to RD8 r f
                break;
            case idleForward:
                leftWheelBackward = 0b0000; // map OC2 to RD1 l b
                leftWheelForward = 0b0000; // map OC2 to RD0 l f
                rightWheelBackward = 0b0000; // map OC2 to RD5 r b
                rightWheelForward = 0b0000; // map OC2 to RD8 r f
                break;
            case idleBackward:
                leftWheelBackward = 0b0000; // map OC2 to RD1 l b
                leftWheelForward = 0b0000; // map OC2 to RD0 l f
                rightWheelBackward = 0b0000; // map OC2 to RD5 r b
                rightWheelForward = 0b0000; // map OC2 to RD8 r f
                break;
        }
        if(IFS0bits.AD1IF){
            IFS0bits.AD1IF=0;
            pinVoltage=ADC1BUF0;
            value=pinVoltage/310;
            sprintf(analogVoltage, "%.2f", value);
            printStringLCD(analogVoltage);
            printCharLCD('V');
            moveCursorLCD(0,0);
            
            
            if(ADC1BUF0>512){
                   OC1RS = (-1023/511)*(ADC1BUF0)+1046529/511;
                   OC2RS = 1023;
            }
            else{
                OC1RS=1023;
                OC2RS=(1023/512)*(ADC1BUF0);
            }

        }
    }
    
    return 0;
}


void __ISR(_CHANGE_NOTICE_VECTOR, IPL7SRS) _CNInterrupt( void ){
    switchPressedFlag = SW1;  
    IFS1bits.CNDIF = 0;
    
    if(!switchPressedFlag){
           if (state == forward) state = idleForward;
           else if(state==backward) state = idleBackward;
           else if(state == idleForward) state = backward;
           else if(state == idleBackward) state = forward; 
    }

}