/* 
 * File:   pwm.h
 * Author: Brit Briggs
 *
 * Created on March 19, 2016, 10:55 AM
 */

#ifndef PWM_H
#define	PWM_H

#define rightWheelForward RPD8Rbits.RPD8R
#define rightWheelBackward  RPD5Rbits.RPD5R
#define leftWheelForward RPD0Rbits.RPD0R
#define leftWheelBackward RPD1Rbits.RPD1R
#define HbridgeEN1 TRISGbits.TRISG0
#define HbridgeEN2 TRISGbits.TRISG13
#define Output 0

    void initPWM1();
    void initPWM2();
    void initHbridge();


#ifdef	__cplusplus
}
#endif

#endif	/* PWM_H */

