
#include <xc.h>
#include <sys/attribs.h>
#include "switch.h"

#define INPUT 1
#define OUTPUT 0

#define ENABLED 1 
#define DISABLED 0


void initSwitch1(){
    TRIS_SW1 = INPUT;           // Configure switch as input
    CNCONDbits.ON = 1;          // Enable overall interrupt
    CNIE_SW1= ENABLED;         // Enable pin CN
    CNPU_SW1 = ENABLED;         // Enable pull-up resistor
    IFS1bits.CNDIF = 0;         // Put down the flag
    IPC8bits.CNIP = 7;          // Configure interrupt priority
    IEC1bits.CNDIE = 1;   // Enable interrupt for D pins
}

