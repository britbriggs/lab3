/* 
 * File:   pwm.h
 * Author: Brit Briggs
 *
 * Created on March 19, 2016, 10:55 AM
 */

#ifndef PWM_H
#define	PWM_H

#ifdef	__cplusplus
extern "C" {
#endif

    void initPWM1();
    void initPWM2();
    void initHbridge();


#ifdef	__cplusplus
}
#endif

#endif	/* PWM_H */

