


#include <xc.h>
#include <sys/attribs.h>
#include "adc.h"
#include "config.h"
#include "interrupt.h"
#include "lcd.h"
#include "pwm.h"


typedef enum stateTypeEnum{
    init, printVtoLCD
} stateType;
volatile stateType state = init;
volatile float pinVoltage=0;
volatile float value=0;


int main(void){
    char analogVoltage[]="0.00";

    SYSTEMConfigPerformance(10000000);

    initHbridge();
    initPWM1();
    initPWM2();
    initADC();
    initTimer2();
    
    initLCD();                  // Initialize LCD

    enableInterrupts();
    moveCursorLCD(0,0);
    
    while(1){
        if(IFS0bits.AD1IF==1){
            IFS0bits.AD1IF=0;
            pinVoltage=ADC1BUF0;
            value=pinVoltage/310;
            sprintf(analogVoltage, "%.2f", value);
            printStringLCD(analogVoltage);
            printCharLCD('V');
            moveCursorLCD(0,0);
        }
        
    }
    
    return 0;
}