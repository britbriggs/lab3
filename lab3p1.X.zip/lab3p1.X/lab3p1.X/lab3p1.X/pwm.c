#include <xc.h>



void initPWM1(){
    RPD1Rbits.RPD1R = 0b0000; // map OC2 to RD1 l b
    RPD0Rbits.RPD0R = 0b0000; // map OC2 to RD0 l f

    OC1CON = 0x0000; // Turn off OC1 while doing setup.
    OC1R = 0; // Initialize primary Compare Register
    OC1RS = 700; // Initialize secondary Compare Register
    OC1CON = 0x0006; // Configure for PWM mode
    OC1CONSET = 0x8000; // Enable OC1
}

void initPWM2(){
    RPD5Rbits.RPD5R = 0b0000; // map OC2 to RD5 r b

    RPD8Rbits.RPD8R = 0b0000; // map OC2 to RD8 r f

    OC2CON = 0x0000; // Turn off OC1 while doing setup.
    OC2R =0; // Initialize primary Compare Register
    OC2RS =900; // Initialize secondary Compare Register
    OC2CON = 0x0006; // Configure for PWM mode
    OC2CONSET = 0x8000; // Enable OC1
}


void initHbridge(){
    TRISGbits.TRISG0=0;
    TRISGbits.TRISG13=0;
    
    LATGbits.LATG0=1;
    LATGbits.LATG13=1;
    
    
    
}